#Herrera, Amirah & Sing, Michael Caspian
class Plant:
    def __init__ (self, name, health, damage):
        self.name = name
        self.health = health
        self.damage = damage

    def attack(self, zombie):
        if self.health > 0:
            zombie.health -= self.damage

    def take_damage(self, damage):
        if self.health > 0:
            self.health -= damage
        else:
            print("Zombies win")

p1 = Plant("Spider Lily", 20, 5)
p2 = Plant("Lily of the Valley", 15, 10)

class Zombie:
    def __init__ (self, name, health, damage, distance):
        self.name = name
        self.health = health
        self.damage = damage
        self.distance = distance

    def move(self):
        if self.health > 0:
            self.distance -= 1
        else:
            print("Plants win")

    def attack(self, plant):
        if self.health > 0:
            plant.health -= self.damage
        else:
            print("Zombies win")

    def take_damage(self, damage):
        if self.health > 0:
            self.health -= damage
        else:
            print("Plants win")

z1 = Zombie("Ivan", 50ss, 10, 1)

while z1.health > 0 and (p1.health > 0 or p2.health > 0):
    z1.move()
    if z1.distance == 0:
        z1.attack(p1)
        z1.attack(p2)
    p1.attack(z1)
    p2.attack(z1)
    print(f"{p1.name} Health: {p1.health}")
    print(f"{p2.name} Health: {p2.health}")
    print(f"{z1.name} Health: {z1.health}")
    print(f"{z1.name} Distance: {z1.distance}")
    print("-----------------------------")
    print("Plants win" if z1.health <= 0 else "Zombies win" if (p1.health <= 0 and p2.health <= 0) else "")